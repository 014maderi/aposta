# Simulador de Apostas - TODO

## MVP (Mínimo Produto Viável) - CONCLUÍDO ✅

- [x] Sistema de autenticação e conta
- [x] Visualização de eventos esportivos
- [x] Sistema de apostas simples
- [x] Histórico de apostas
- [x] Ranking de apostadores
- [x] Chat da comunidade
- [x] Notificações
- [x] Interface responsiva
- [x] Placar ao vivo (simulado)
- [x] Bônus e promoções (estrutura)

## Funcionalidades Futuras

- [ ] Persistência de dados (localStorage)
- [ ] Autenticação real (login/registro)
- [ ] Resultados automáticos de eventos
- [ ] Apostas múltiplas (parlay)
- [ ] Diferentes tipos de apostas (handicap, over/under)
- [ ] Backend com API
- [ ] Banco de dados
- [ ] Chat em tempo real com WebSocket
- [ ] Notificações push
- [ ] Gráficos de desempenho
- [ ] Sistema de bônus avançado
- [ ] Verificação de identidade
- [ ] Métodos de pagamento
- [ ] Suporte ao cliente
- [ ] Análise de dados e relatórios
