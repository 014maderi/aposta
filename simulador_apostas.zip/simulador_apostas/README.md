# Simulador de Apostas Esportivas

Um website educacional completo de simulador de apostas esportivas desenvolvido com HTML, CSS e JavaScript vanilla.

## 🎯 Funcionalidades Implementadas

### 1. **Sistema de Autenticação e Conta**
- Usuário inicia com saldo de R$ 1.000,00 em créditos fictícios
- Saldo atualizado em tempo real após cada aposta
- Informações do usuário exibidas no header

### 2. **Eventos Esportivos**
- 4 eventos de futebol simulados com times brasileiros
- Cada evento possui 3 opções de apostas (Vitória 1, Empate, Vitória 2)
- Odds realistas para cada resultado
- Status de evento (aberto/fechado)

### 3. **Sistema de Apostas**
- **Apostas Simples**: Selecione um resultado e defina o valor
- **Validação**: Verifica saldo suficiente antes de confirmar
- **Cálculo de Ganho Potencial**: Mostra quanto você pode ganhar
- **Modal Interativo**: Interface clara para realizar apostas

### 4. **Histórico de Apostas**
- Visualize todas as apostas realizadas
- Status de cada aposta (Pendente, Ganhou, Perdeu)
- Data, hora, valor apostado e possível ganho
- Histórico atualizado em tempo real

### 5. **Ranking de Apostadores**
- Top 5 apostadores com melhor desempenho
- Exibição de saldo, apostas ganhas e taxa de acerto
- Medalhas para os 3 primeiros colocados
- Você aparece no ranking com seus dados

### 6. **Comunidade e Chat**
- Chat em tempo real com outros usuários
- Envie mensagens para compartilhar dicas e comentários
- Histórico de mensagens durante a sessão
- Interface simples e intuitiva

### 7. **Notificações**
- Mensagens de sucesso após realizar apostas
- Alertas de erro (saldo insuficiente, valor inválido)
- Notificações animadas no canto superior direito

### 8. **Interface Responsiva**
- Design moderno com tema escuro
- Funciona em desktop, tablet e mobile
- Navegação por abas para diferentes seções
- Animações suaves e transições

---

## 📁 Estrutura do Projeto

```
simulador_apostas/
├── index.html       # Arquivo principal com HTML, CSS e JavaScript
├── package.json     # Configuração do projeto
├── README.md        # Este arquivo
└── todo.md          # Rastreamento de funcionalidades
```

---

## 🚀 Como Usar

### Opção 1: Abrir Diretamente no Navegador

1. Navegue até a pasta do projeto:
   ```bash
   cd /home/ubuntu/simulador_apostas
   ```

2. Abra o arquivo `index.html` no seu navegador:
   ```bash
   # No Linux/Mac
   open index.html

   # No Windows
   start index.html
   ```

### Opção 2: Usar um Servidor Local (Recomendado)

Se você tiver Python instalado:

```bash
# Python 3
python3 -m http.server 8000

# Python 2
python -m SimpleHTTPServer 8000
```

Depois, acesse `http://localhost:8000` no seu navegador.

---

## 🎮 Como Jogar

1. **Explore os Eventos**: Na aba "Eventos", você verá os jogos disponíveis para apostas
2. **Selecione um Resultado**: Clique em uma das odds (Vitória 1, Empate ou Vitória 2)
3. **Defina o Valor**: Na janela que aparecer, insira o valor que deseja apostar
4. **Confirme**: Clique em "Confirmar" para realizar a aposta
5. **Acompanhe**: Veja suas apostas na aba "Minhas Apostas"
6. **Compete**: Verifique seu ranking na aba "Ranking"
7. **Converse**: Participe da comunidade na aba "Comunidade"

---

## 💡 Conceitos Educacionais

Este simulador demonstra:

- **Odds e Probabilidades**: Como as odds funcionam em apostas esportivas
- **Gerenciamento de Risco**: Importância de controlar o valor apostado
- **Análise de Dados**: Visualização de histórico e estatísticas
- **Interação em Tempo Real**: Chat e atualizações dinâmicas
- **Gamificação**: Ranking e competição entre usuários

---

## 📊 Dados Simulados

### Eventos Iniciais

| Time 1 | Time 2 | Data | Vitória 1 | Empate | Vitória 2 |
| :--- | :--- | :--- | :--- | :--- | :--- |
| Flamengo | Vasco | 20/11 19:00 | 1.85 | 3.20 | 4.50 |
| São Paulo | Corinthians | 20/11 21:00 | 2.10 | 3.10 | 3.80 |
| Palmeiras | Botafogo | 21/11 18:00 | 1.65 | 3.50 | 5.20 |
| Grêmio | Inter | 21/11 20:00 | 2.30 | 3.00 | 3.50 |

### Ranking Inicial

| Posição | Usuário | Saldo | Apostas Ganhas |
| :--- | :--- | :--- | :--- |
| 🥇 | João Silva | R$ 5.000 | 45/100 |
| 🥈 | Maria Santos | R$ 4.200 | 38/95 |
| 🥉 | Você | R$ 1.000 | 0/0 |
| 4º | Pedro Costa | R$ 2.800 | 22/80 |
| 5º | Ana Oliveira | R$ 2.100 | 18/75 |

---

## 🔧 Tecnologias Utilizadas

- **HTML5**: Estrutura semântica da página
- **CSS3**: Estilização com tema escuro moderno
- **JavaScript Vanilla**: Lógica da aplicação sem dependências externas

---

## 📝 Notas Importantes

Este é um **simulador educacional** e não realiza transações reais. Todos os dados são armazenados apenas na memória do navegador e serão perdidos ao recarregar a página.

### Limitações Atuais

- Dados não persistem entre sessões (use localStorage para persistência)
- Apostas não têm resultados automáticos (implementar lógica de sorteio)
- Chat é local apenas (implementar backend para chat real)
- Sem autenticação real (implementar sistema de login)

---

## 🚀 Próximos Passos para Expandir

1. **Persistência de Dados**
   - Usar `localStorage` para salvar dados entre sessões
   - Implementar backend com banco de dados

2. **Autenticação Real**
   - Sistema de login e registro
   - Validação de credenciais

3. **Resultados de Eventos**
   - Implementar sorteio de resultados
   - Atualizar apostas automaticamente
   - Calcular ganhos/perdas

4. **Backend e API**
   - Criar servidor Node.js/Express
   - Implementar endpoints para apostas
   - Sincronizar dados em tempo real

5. **Recursos Avançados**
   - Apostas múltiplas (parlay)
   - Diferentes tipos de apostas (handicap, over/under)
   - Sistema de bônus e promoções
   - Notificações push
   - Gráficos de desempenho

6. **Segurança**
   - Validação de entrada no servidor
   - Proteção contra fraude
   - Criptografia de dados sensíveis

---

## 📞 Suporte

Para dúvidas ou sugestões sobre o simulador, consulte a documentação ou experimente as funcionalidades disponíveis.

---

Desenvolvido com ❤️ para fins educacionais.
